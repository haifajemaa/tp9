import { Component,OnInit,signal,inject } from '@angular/core';
import { Game } from '../../models/game';
import { Category } from '../../models/category';
import { form, FormField, FormRoot } from '@angular/forms/signals';
import { GameService } from '../../services/game-service';
import { JsonPipe } from '@angular/common';

@Component({
  imports: [FormRoot,FormField,JsonPipe],
  selector: 'app-game-add',
  styleUrl: './game-add.css',
  templateUrl: './game-add.html',
})
export class GameAdd  implements OnInit{
  categories=Object.values(Category);
  private gameService=inject(GameService);
  readonly gameModel = signal<Game>({
id:"",
name: "",
price:0,
madeIn:"Tunisie",
category:Category.Puzzle,
isNew: true,
shops: []})
readonly gameForm= form(this.gameModel);
onSubmit(){
console.log(this.gameModel())
this.gameService.addGame(this.gameModel()).subscribe();
this.resetForm();
}
resetForm(){
this.gameModel.set({
id:"",
name: "",
price:0,
madeIn:"Tunisie",
category:Category.Puzzle,
isNew: true,
shops: []})}
games = this.gameService.games;
ngOnInit(): void {
  this.gameService.getGames().subscribe();
}
}